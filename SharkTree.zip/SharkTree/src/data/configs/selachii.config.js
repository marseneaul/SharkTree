import { galeomorphiiConfig } from "./galeomorphii.config";
import { squalomorphiiConfig } from "./squalomorphii.config";

export const selachiiConfig = {
    children: [
        galeomorphiiConfig,
        squalomorphiiConfig
    ]
}