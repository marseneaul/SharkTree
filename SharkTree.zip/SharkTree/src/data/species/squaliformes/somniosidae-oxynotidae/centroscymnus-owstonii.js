export const centroscymnusOwstonii = {
    commonName: "Roughskin Dogfish",
    binomialName: "Centroscymnus owstonii",

    domain:	"Eukaryota",
    kingdom: "Animalia",
    phylum:	"Chordata",
    class: "Chondrichthyes",
    subclass: "Elasmobranchii",
    subdivision: "Selachimorpha",
    superorder: "Squalomorphii",
    order: "Squaliformes",
    family: "Somniosidae",
    genus: "Centroscyllium",
    species: "owstonii"
};