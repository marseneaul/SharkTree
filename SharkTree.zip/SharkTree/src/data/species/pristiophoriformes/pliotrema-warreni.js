export const pliotremaWarreni = {
    commonName: "Sixgill Sawshark",
    binomialName: "Pliotrema warreni",

    domain:	"Eukaryota",
    kingdom: "Animalia",
    phylum:	"Chordata",
    class: "Chondrichthyes",
    subclass: "Elasmobranchii",
    subdivision: "Selachimorpha",
    superorder: "Squalomorphii",
    order: "Pristiophoriformes",
    family: "Pristiophoridae",
    genus: "Pliotrema",
    species: "warreni"
};