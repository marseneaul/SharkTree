export const mitsukurinaOwstoni = {
    commonName: "Goblin Shark",
    binomialName: "Mitsukruina owstoni",

    domain:	"Eukaryota",
    kingdom: "Animalia",
    phylum:	"Chordata",
    class: "Chondrichthyes",
    subclass: "Elasmobranchii",
    subdivision: "Selachimorpha",
    superorder: "Galeomorphii",
    order: "Lamniformes",
    family: "Mitsukurinidae",
    genus: "Mitsukruina",
    species: "owstoni"
};