export const hexanchusNakamurai = {
    commonName: "Bigeye Sixgill Shark",
    binomialName: "Hexanchus nakamurai",

    domain:	"Eukaryota",
    kingdom: "Animalia",
    phylum:	"Chordata",
    class: "Chondrichthyes",
    subclass: "Elasmobranchii",
    subdivision: "Selachimorpha",
    superorder: "Squalomorphii",
    order: "Hexanchiformes",
    family: "Hexanchidae",
    genus: "Hexanchus",
    species: "nakamurai"
};