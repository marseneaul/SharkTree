export const asymbolusParvus = {
    commonName: "Dwarf Catshark",
    binomialName: "Asymbolus parvus",

    domain:	"Eukaryota",
    kingdom: "Animalia",
    phylum:	"Chordata",
    class: "Chondrichthyes",
    subclass: "Elasmobranchii",
    subdivision: "Selachimorpha",
    superorder: "Galeomorphii",
    order: "Carcharhiniformes",
    family: "Scyliorhinidae",
    genus: "Asymbolus",
    species: "parvus"
}