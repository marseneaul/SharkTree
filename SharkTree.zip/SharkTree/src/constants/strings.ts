export const SVG_NAMESPACE = "http://www.w3.org/2000/svg";

// Shark Descriptors
export const SPIRACLE = "Spiracle";
export const ANAL_FIN = "Anal Fin";
export const NO_ANAL_FIN = "No Anal Fin";
export const NICTITATING_MEMBRANE = "Nictitating Membrane";
export const ONE_DORSAL_FIN = "One Dorsal Fin";
export const TWO_DORSAL_FINS = "Two Dorsal Fins";
export const FIVE_GILLS = "Five Gills";
export const SIX_GILLS = "Six Gills";
export const SEVEN_GILLS = "Seven Gills";
export const DORSAL_SPINES = "Dorsal Spines";
export const WARM_BLOODED = "Warm-Blooded";
export const COLD_BLOODED = "Cold-Blooded";